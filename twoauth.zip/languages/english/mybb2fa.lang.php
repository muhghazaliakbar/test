<?php
$l['mybb2fa_activated'] = "Two Factor Authentication has been activated. Please scan the QR Code now.";
$l['mybb2fa_loggedin'] = "The code was correct, you're logged in now";
$l['mybb2fa_failed'] = "The code was incorrect, you're logged out now";
$l['mybb2fa'] = "MyBB Two Factor Authentication";
$l['mybb2fa_code'] = "Please enter the authentication code";
$l['mybb2fa_check'] = "Check";
$l['mybb2fa_activated_desc'] = "Two Factor Authentication is activated at the moment. Please scan the QR Code below to make sure you can log in to your account.";
$l['mybb2fa_deactivate'] = "Deactivate";
$l['mybb2fa_deactivated_desc'] = "Two Factor Authentication is deactivated at the moment. Note that you need a smartphone with an app like Google Authenticator or Authy to use Two Factor Authentication.";
$l['mybb2fa_activate'] = "Activate";