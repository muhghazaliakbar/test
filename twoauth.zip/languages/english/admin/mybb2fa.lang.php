<?php
$l['mybb2fa_task'] = "{1} code(s) deleted, {2} sessions closed and {3} admins kicked";
$l['mybb2fa_failed'] = "The code was incorrect, you're logged out now";
$l['mybb2fa'] = "MyBB Two Factor Authentication";
$l['mybb2fa_code'] = "Please enter the authentication code";
$l['mybb2fa_label'] = "Authentication code:";